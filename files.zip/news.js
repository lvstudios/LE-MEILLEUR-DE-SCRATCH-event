fetch('news.txt')
  .then(r => r.text())
  .then(text => {
    const articles = text.split('---').map(block => {
      const title = (block.match(/Titre:\s*(.+)/) || [])[1];
      const content = (block.match(/Contenu:\s*([\s\S]*?)\nDate:/) || [])[1];
      const date = (block.match(/Date:\s*(.+)/) || [])[1];
      return title && content && date ? { title, content: content.trim(), date } : null;
    }).filter(Boolean);

    const newsList = document.getElementById('news-list');
    if (!articles.length) {
      newsList.innerHTML = '<p class="animate">Aucune news pour le moment.</p>';
    } else {
      articles.forEach(item => {
        const block = document.createElement('div');
        block.className = 'news-item animate';
        block.innerHTML = `
          <h3>${item.title}</h3>
          <p>${item.content}</p>
          <div class="news-date">${item.date}</div>
        `;
        newsList.appendChild(block);
      });
    }
  });