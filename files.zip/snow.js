// Simple snow animation
const snowContainer = document.getElementById("snow");
function createSnowflake() {
    const snowflake = document.createElement("div");
    snowflake.classList.add("snowflake");
    snowflake.style.left = Math.random() * window.innerWidth + "px";
    snowflake.style.animationDuration = (Math.random() * 2 + 3) + "s";
    snowflake.style.opacity = Math.random();
    snowflake.style.fontSize = Math.random() * 12 + 10 + "px";
    snowflake.textContent = "❄";
    snowContainer.appendChild(snowflake);
    setTimeout(() => snowflake.remove(), 5000);
}
setInterval(createSnowflake, 150);

const snowStyle = document.createElement('style');
snowStyle.textContent = `
.snowflake {
  position: fixed;
  top: -2em;
  color: #fff;
  user-select: none;
  pointer-events: none;
  z-index: 10000;
  will-change: transform;
  animation: fall linear forwards;
}
@keyframes fall {
  to {
    transform: translateY(100vh);
  }
}
`;
document.head.appendChild(snowStyle);